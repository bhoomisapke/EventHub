import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CalendarDays,
  Clock3,
  MapPin,
  Users,
  UserRound,
  Phone,
  IndianRupee,
  ImagePlus,
  FileText,
  Sparkles,
} from "lucide-react";
import "./CreateEvent.css";

function CreateEvent() {
  const navigate = useNavigate();

  const [event, setEvent] = useState({
    title: "",
    category: "",
    date: "",
    time: "",
    venue: "",
    organizerName: "",
    organizerMobile: "",
    capacity: "",
    registrationFee: "",
    customFee: "",
    registrationDeadline: "",
    description: "",
    image: null,
  });

  const [imagePreview, setImagePreview] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setEvent((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("Please select a valid image file.");
      return;
    }

    setEvent((previous) => ({
      ...previous,
      image: file,
    }));

    const previewUrl = URL.createObjectURL(file);
    setImagePreview(previewUrl);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !event.title ||
      !event.date ||
      !event.venue ||
      !event.organizerName ||
      !event.organizerMobile ||
      !event.capacity ||
      !event.registrationFee
    ) {
      alert("Please fill in all required fields.");
      return;
    }

    if (!/^[0-9]{10}$/.test(event.organizerMobile)) {
      alert("Please enter a valid 10-digit mobile number.");
      return;
    }

    if (
      event.registrationFee === "Custom" &&
      (!event.customFee || Number(event.customFee) <= 0)
    ) {
      alert("Please enter a valid custom registration fee.");
      return;
    }

    if (
      event.registrationDeadline &&
      event.registrationDeadline > event.date
    ) {
      alert("Registration deadline cannot be after the event date.");
      return;
    }

    try {
      setIsSubmitting(true);

      const formData = new FormData();

      formData.append("title", event.title);
      formData.append("category", event.category);
      formData.append("date", event.date);
      formData.append("time", event.time);
      formData.append("venue", event.venue);
      formData.append("organizerName", event.organizerName);
      formData.append("organizerMobile", event.organizerMobile);
      formData.append("capacity", event.capacity);

      const fee =
        event.registrationFee === "Free"
          ? "0"
          : event.registrationFee === "Custom"
            ? event.customFee
            : event.registrationFee;

      formData.append("registrationFee", fee);

      if (event.registrationDeadline) {
        formData.append(
          "registrationDeadline",
          event.registrationDeadline
        );
      }

      formData.append("description", event.description);

      if (event.image) {
        formData.append("image", event.image);
      }

      const response = await fetch(
        "http://localhost:8000/api/events/",
        {
          method: "POST",
          body: formData,
        }
      );

      const data = await response.json();

      if (!response.ok) {
        console.error("Create event response:", data);

        alert(
          data?.detail ||
            data?.message ||
            "Failed to create event."
        );

        return;
      }

      console.log("Created event:", data);

      alert("Event created successfully!");

      navigate("/organizer/events");
    } catch (error) {
      console.error("Create event error:", error);

      alert(
        "Unable to connect to the backend. Make sure the backend server is running."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="create-event-page">

      {/* Decorative background */}
      <div className="create-event-glow create-glow-one"></div>
      <div className="create-event-glow create-glow-two"></div>

      <div className="create-event-container">

        {/* =========================================
            PAGE HEADER
        ========================================= */}

        <div className="create-event-header">

          <div className="create-event-heading">

            <span className="create-event-label">
              <Sparkles size={14} />
              ORGANIZER EVENTS
            </span>

            <h1>
              Create <span>Event.</span>
            </h1>

            <p>
              Create an exciting event and share it with your students.
            </p>

          </div>

        </div>


        {/* =========================================
            FORM
        ========================================= */}

        <form
          className="create-event-form"
          onSubmit={handleSubmit}
        >

          {/* =========================================
              EVENT IMAGE
          ========================================= */}

          <section className="create-form-section">

            <div className="section-heading">

              <div className="section-icon">
                <ImagePlus size={19} />
              </div>

              <div>
                <span>01</span>
                <h2>Event Image</h2>
                <p>
                  Add an attractive image for your event.
                </p>
              </div>

            </div>


            <label className="create-image-upload">

              {imagePreview ? (

                <div className="create-image-preview-container">

                  <img
                    src={imagePreview}
                    alt="Event preview"
                    className="create-event-image-preview"
                  />

                  <div className="change-image-overlay">
                    <ImagePlus size={20} />
                    <span>Change Image</span>
                  </div>

                </div>

              ) : (

                <div className="create-upload-placeholder">

                  <div className="upload-image-icon">
                    <ImagePlus size={28} />
                  </div>

                  <strong>
                    Upload Event Image
                  </strong>

                  <span>
                    JPG, PNG or WEBP
                  </span>

                  <small>
                    Recommended for the best appearance
                  </small>

                </div>

              )}

              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={handleImageChange}
                hidden
              />

            </label>

          </section>


          {/* =========================================
              EVENT INFORMATION
          ========================================= */}

          <section className="create-form-section">

            <div className="section-heading">

              <div className="section-icon">
                <CalendarDays size={19} />
              </div>

              <div>
                <span>02</span>
                <h2>Event Information</h2>
                <p>
                  Tell students everything they need to know.
                </p>
              </div>

            </div>


            {/* Event title */}

            <div className="create-form-group">

              <label>
                Event Title <span>*</span>
              </label>

              <input
                type="text"
                name="title"
                value={event.title}
                onChange={handleChange}
                placeholder="Enter event title"
                required
              />

            </div>


            {/* Category + Capacity */}

            <div className="create-form-row">

              <div className="create-form-group">

                <label>
                  Category
                </label>

                <select
                  name="category"
                  value={event.category}
                  onChange={handleChange}
                >

                  <option value="">
                    Select category
                  </option>

                  <option value="Technology">
                    Technology
                  </option>

                  <option value="Cultural">
                    Cultural
                  </option>

                  <option value="Sports">
                    Sports
                  </option>

                  <option value="Workshop">
                    Workshop
                  </option>

                  <option value="Competition">
                    Competition
                  </option>

                  <option value="Seminar">
                    Seminar
                  </option>

                </select>

              </div>


              <div className="create-form-group">

                <label>
                  Maximum Participants <span>*</span>
                </label>

                <div className="input-with-icon">

                  <Users size={17} />

                  <input
                    type="number"
                    name="capacity"
                    value={event.capacity}
                    onChange={handleChange}
                    placeholder="100"
                    min="1"
                    required
                  />

                </div>

              </div>

            </div>


            {/* Date + Time */}

            <div className="create-form-row">

              <div className="create-form-group">

                <label>
                  Event Date <span>*</span>
                </label>

                <div className="input-with-icon">

                  <CalendarDays size={17} />

                  <input
                    type="date"
                    name="date"
                    value={event.date}
                    onChange={handleChange}
                    required
                  />

                </div>

              </div>


              <div className="create-form-group">

                <label>
                  Event Time
                </label>

                <div className="input-with-icon">

                  <Clock3 size={17} />

                  <input
                    type="time"
                    name="time"
                    value={event.time}
                    onChange={handleChange}
                  />

                </div>

              </div>

            </div>


            {/* Venue + Organizer */}

            <div className="create-form-row">

              <div className="create-form-group">

                <label>
                  Venue <span>*</span>
                </label>

                <div className="input-with-icon">

                  <MapPin size={17} />

                  <input
                    type="text"
                    name="venue"
                    value={event.venue}
                    onChange={handleChange}
                    placeholder="Example: Seminar Hall"
                    required
                  />

                </div>

              </div>


              <div className="create-form-group">

                <label>
                  Organizer Name <span>*</span>
                </label>

                <div className="input-with-icon">

                  <UserRound size={17} />

                  <input
                    type="text"
                    name="organizerName"
                    value={event.organizerName}
                    onChange={handleChange}
                    placeholder="Enter organizer name"
                    required
                  />

                </div>

              </div>

            </div>


            {/* Organizer Mobile */}

            <div className="create-form-group">

              <label>
                Organizer Mobile Number <span>*</span>
              </label>

              <div className="mobile-input-wrapper">

                <div className="mobile-country-code">
                  +91
                </div>

                <div className="mobile-input-icon">
                  <Phone size={17} />
                </div>

                <input
                  type="tel"
                  name="organizerMobile"
                  value={event.organizerMobile}
                  onChange={handleChange}
                  placeholder="Enter 10-digit mobile number"
                  maxLength="10"
                  inputMode="numeric"
                  required
                />

              </div>

              <small className="create-form-help">
                Students can use this number to contact the organizer.
              </small>

            </div>


            {/* Registration Fee */}

            <div className="create-form-group">

              <label>
                Registration Fee <span>*</span>
              </label>

              <div className="input-with-icon">

                <IndianRupee size={17} />

                <select
                  name="registrationFee"
                  value={event.registrationFee}
                  onChange={handleChange}
                  required
                >

                  <option value="">
                    Select registration fee
                  </option>

                  <option value="Free">
                    Free
                  </option>

                  <option value="20">
                    ₹20
                  </option>

                  <option value="50">
                    ₹50
                  </option>

                  <option value="100">
                    ₹100
                  </option>

                  <option value="Custom">
                    Custom
                  </option>

                </select>

              </div>


              {event.registrationFee === "Custom" && (

                <input
                  className="custom-fee-input"
                  type="number"
                  name="customFee"
                  value={event.customFee}
                  onChange={handleChange}
                  placeholder="Enter custom amount (₹)"
                  min="1"
                  required
                />

              )}

            </div>


            {/* Registration Deadline */}

            <div className="create-form-group">

              <label>
                Registration Deadline
              </label>

              <div className="input-with-icon">

                <CalendarDays size={17} />

                <input
                  type="date"
                  name="registrationDeadline"
                  value={event.registrationDeadline}
                  onChange={handleChange}
                  max={event.date || undefined}
                />

              </div>

              <small className="create-form-help">
                Last date for students to register for this event.
              </small>

            </div>


            {/* Description */}

            <div className="create-form-group">

              <label>
                Description
              </label>

              <div className="textarea-wrapper">

                <FileText size={17} />

                <textarea
                  name="description"
                  value={event.description}
                  onChange={handleChange}
                  placeholder="Describe your event..."
                  rows="6"
                />

              </div>

            </div>

          </section>


          {/* =========================================
              ACTIONS
          ========================================= */}

          <div className="create-event-actions">

            <button
              type="button"
              className="create-cancel-btn"
              onClick={() =>
                navigate("/organizer/dashboard")
              }
            >
              Cancel
            </button>

            <button
              type="submit"
              className="create-save-btn"
              disabled={isSubmitting}
            >
              {isSubmitting
                ? "Saving..."
                : "Save Event"}
            </button>

          </div>

        </form>

      </div>

    </div>
  );
}

export default CreateEvent;